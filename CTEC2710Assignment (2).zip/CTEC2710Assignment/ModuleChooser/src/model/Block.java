package model;

public enum Block {
	BLOCK_1, BLOCK_2, BLOCK_3_4
}
