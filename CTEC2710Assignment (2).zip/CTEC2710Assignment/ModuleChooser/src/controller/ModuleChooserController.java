package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.stage.FileChooser;
import model.Block;
import model.Course;
import model.Module;
import model.Name;
import model.StudentProfile;
import view.CreateStudentProfilePane;
import view.ModuleChooserMenuBar;
import view.ModuleChooserRootPane;
import view.OverviewPane;
import view.ReserveModulesPane;
import view.SelectModulesPane;

/**
 * Controller for the JavaFX Module Chooser application.
 * Implements the required behaviour as described in the assignment brief.
 */
public class ModuleChooserController {

	private StudentProfile model;
	private final ModuleChooserRootPane view;

	// view sub containers
	private final CreateStudentProfilePane cspp;
	private final SelectModulesPane smp;
	private final ReserveModulesPane rmp;
	private final OverviewPane op;
	private final ModuleChooserMenuBar mstmb;

	// data
	private final Course[] courses;
	private Course activeCourse;

	public ModuleChooserController(StudentProfile model, ModuleChooserRootPane view) {
		this.model = model;
		this.view = view;

		cspp = view.getCreateStudentProfilePane();
		smp = view.getSelectModulesPane();
		rmp = view.getReserveModulesPane();
		op = view.getOverviewPane();
		mstmb = view.getModuleSelectionToolMenuBar();

		courses = generateAndGetCourses();
		cspp.addCourseDataToComboBox(courses);

		setTabUsability(false);
		attachEventHandlers();
	}

	private void setTabUsability(boolean afterProfileCreated) {
		// disable other tabs' primary actions until a profile is created
		smp.setSelectionControlsEnabled(afterProfileCreated);
		rmp.setControlsEnabled(afterProfileCreated);
		op.setControlsEnabled(afterProfileCreated);
	}

	private void attachEventHandlers() {
		cspp.addCreateStudentProfileHandler(new CreateStudentProfileHandler());

		smp.addAddHandler(new AddOptionalHandler());
		smp.addRemoveHandler(new RemoveOptionalHandler());
		smp.addResetHandler(new ResetHandler());
		smp.addSubmitHandler(new SubmitHandler());

		rmp.addAddHandler(new AddReserveHandler());
		rmp.addRemoveHandler(new RemoveReserveHandler());
		rmp.addConfirmHandler(new ConfirmHandler());

		op.addSaveOverviewHandler(new SaveOverviewHandler());

		mstmb.addSaveHandler(new SaveProfileHandler());
		mstmb.addLoadHandler(new LoadProfileHandler());
		mstmb.addAboutHandler(e -> showInfo("About", "Final Year Module Selection Tool\n\nJavaFX MVC prototype for selecting modules and saving/loading student data."));
		mstmb.addExitHandler(e -> {
			Alert a = new Alert(AlertType.CONFIRMATION, "Exit the application?", ButtonType.YES, ButtonType.NO);
			a.setHeaderText(null);
			a.showAndWait().ifPresent(btn -> {
				if (btn == ButtonType.YES) System.exit(0);
			});
		});
	}

	// -------------------- Handlers --------------------

	private class CreateStudentProfileHandler implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent event) {
			Course course = cspp.getSelectedCourse();
			String pnum = safeTrim(cspp.getStudentPnumber());
			Name name = cspp.getStudentName();
			String email = safeTrim(cspp.getStudentEmail());
			LocalDate date = cspp.getStudentDate();

			List<String> errors = validateProfile(course, pnum, name, email, date);
			if (!errors.isEmpty()) {
				showError("Profile not created", String.join("\n", errors));
				return;
			}

			activeCourse = course;
			model.setStudentCourse(course);
			model.setStudentPnumber(pnum);
			model.setStudentName(name);
			model.setStudentEmail(email);
			model.setSubmissionDate(date);
			model.clearSelectedModules();
			model.clearReservedModules();

			populateSelectModulesForCourse(activeCourse);
			populateReserveModulesEmpty();
			populateOverviewEmpty();

			setTabUsability(true);
			view.changeTab(1);
		}
	}

	private class ResetHandler implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent event) {
			if (activeCourse == null) {
				showError("Nothing to reset", "Please create a profile first.");
				return;
			}
			populateSelectModulesForCourse(activeCourse);
			view.changeTab(1);
		}
	}

	private class AddOptionalHandler implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent event) {
			Module selected = smp.getUnselectedBlock34ListView().getSelectionModel().getSelectedItem();
			if (selected == null) {
				showError("No module selected", "Please select a module from the unselected Block 3/4 list.");
				return;
			}

			// only one optional module can be selected (project module stays selected)
			int optionalChosen = countOptionalChosen();
			if (optionalChosen >= 1) {
				showError("Too many optional modules", "You can only choose one optional Block 3/4 module (30 credits).");
				return;
			}

			moveModule(selected, smp.getUnselectedBlock34ListView(), smp.getSelectedBlock34ListView());
			updateCreditsLabel();
		}
	}

	private class RemoveOptionalHandler implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent event) {
			Module selected = smp.getSelectedBlock34ListView().getSelectionModel().getSelectedItem();
			if (selected == null) {
				showError("No module selected", "Please select a module from the selected Block 3/4 list.");
				return;
			}
			if (selected.isMandatory()) {
				showError("Cannot remove", "Compulsory modules cannot be removed.");
				return;
			}
			moveModule(selected, smp.getSelectedBlock34ListView(), smp.getUnselectedBlock34ListView());
			updateCreditsLabel();
		}
	}

	private class SubmitHandler implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent event) {
			if (activeCourse == null) {
				showError("No profile", "Please create a profile first.");
				return;
			}
			int credits = getCurrentSelectedCredits();
			if (credits != 120) {
				showError("Invalid selection", "Your selection must total 120 credits. Current credits: " + credits);
				return;
			}
			if (countOptionalChosen() != 1) {
				showError("Invalid selection", "Please choose exactly one optional Block 3/4 module.");
				return;
			}

			// store selected modules in model
			model.clearSelectedModules();
			model.clearReservedModules();
			for (Module m : smp.getSelectedBlock1ListView().getItems()) model.addSelectedModule(m);
			for (Module m : smp.getSelectedBlock2ListView().getItems()) model.addSelectedModule(m);
			for (Module m : smp.getSelectedBlock34ListView().getItems()) model.addSelectedModule(m);

			populateReserveModulesFromRemaining();
			view.changeTab(2);
		}
	}

	private class AddReserveHandler implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent event) {
			Module selected = rmp.getUnselectedListView().getSelectionModel().getSelectedItem();
			if (selected == null) {
				showError("No module selected", "Please select a module from the available list.");
				return;
			}
			if (!rmp.getReservedListView().getItems().isEmpty()) {
				showError("Only one reserve", "You can only select one reserve module.");
				return;
			}
			moveModule(selected, rmp.getUnselectedListView(), rmp.getReservedListView());
		}
	}

	private class RemoveReserveHandler implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent event) {
			Module selected = rmp.getReservedListView().getSelectionModel().getSelectedItem();
			if (selected == null) {
				showError("No module selected", "Please select the reserve module to remove.");
				return;
			}
			moveModule(selected, rmp.getReservedListView(), rmp.getUnselectedListView());
		}
	}

	private class ConfirmHandler implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent event) {
			if (rmp.getReservedListView().getItems().size() != 1) {
				showError("Reserve not chosen", "Please choose exactly one reserve module.");
				return;
			}
			Module reserve = rmp.getReservedListView().getItems().get(0);
			model.clearReservedModules();
			model.addReservedModule(reserve);

			populateOverviewFromModel();
			view.changeTab(3);
		}
	}

	private class SaveOverviewHandler implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent event) {
			if (model.getStudentCourse() == null) {
				showError("Nothing to save", "Please complete the selection first.");
				return;
			}
			FileChooser fc = new FileChooser();
			fc.setTitle("Save Overview");
			fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text files", "*.txt"));
			File f = fc.showSaveDialog(view.getScene().getWindow());
			if (f == null) return;
			try (PrintWriter pw = new PrintWriter(f)) {
				pw.println("=== Student Details ===");
				pw.println(op.getProfileText());
				pw.println();
				pw.println("=== Selected Modules ===");
				pw.println(op.getSelectedText());
				pw.println();
				pw.println("=== Reserve Module ===");
				pw.println(op.getReservedText());
				showInfo("Saved", "Overview saved successfully.");
			} catch (IOException ex) {
				showError("Save failed", ex.getMessage());
			}
		}
	}

	private class SaveProfileHandler implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent event) {
			if (model.getStudentCourse() == null) {
				showError("Nothing to save", "Please create a profile (and ideally submit a selection) before saving.");
				return;
			}
			FileChooser fc = new FileChooser();
			fc.setTitle("Save Student Data");
			fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Binary files", "*.dat"));
			File f = fc.showSaveDialog(view.getScene().getWindow());
			if (f == null) return;
			try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f))) {
				oos.writeObject(model);
				showInfo("Saved", "Student data saved successfully.");
			} catch (IOException ex) {
				showError("Save failed", ex.getMessage());
			}
		}
	}

	private class LoadProfileHandler implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent event) {
			FileChooser fc = new FileChooser();
			fc.setTitle("Load Student Data");
			fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Binary files", "*.dat"));
			File f = fc.showOpenDialog(view.getScene().getWindow());
			if (f == null) return;
			try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))) {
				Object obj = ois.readObject();
				if (!(obj instanceof StudentProfile sp)) {
					showError("Load failed", "File did not contain a StudentProfile object.");
					return;
				}
				thisLoad(sp);
				showInfo("Loaded", "Student data loaded successfully.");
			} catch (IOException | ClassNotFoundException ex) {
				showError("Load failed", ex.getMessage());
			}
		}

		private void thisLoad(StudentProfile sp) {
			model = sp;
			activeCourse = matchCourseFromLoaded(sp.getStudentCourse());
			if (activeCourse == null) activeCourse = sp.getStudentCourse();

			// populate create profile form
			cspp.setSelectedCourse(activeCourse);
			cspp.setStudentPnumber(sp.getStudentPnumber());
			cspp.setStudentName(sp.getStudentName());
			cspp.setStudentEmail(sp.getStudentEmail());
			cspp.setStudentDate(sp.getSubmissionDate());

			// populate select modules tab
			populateSelectModulesForCourse(activeCourse);
			if (!sp.getAllSelectedModules().isEmpty()) {
				applySelectedModulesFromModel(sp.getAllSelectedModules());
			}
			updateCreditsLabel();

			// populate reserve tab
			if (!sp.getAllSelectedModules().isEmpty()) {
				populateReserveModulesFromRemaining();
			}
			if (!sp.getAllReservedModules().isEmpty()) {
				Module res = sp.getAllReservedModules().iterator().next();
				// ensure reserve is in reserved list
				rmp.getReservedListView().getItems().clear();
				rmp.getUnselectedListView().getItems().remove(res);
				rmp.getReservedListView().getItems().add(res);
			}

			populateOverviewFromModel();
			setTabUsability(true);
			view.changeTab(3);
		}
	}

	// -------------------- Populate / Helpers --------------------

	private void populateSelectModulesForCourse(Course course) {
		ObservableList<Module> b1 = FXCollections.observableArrayList();
		ObservableList<Module> b2 = FXCollections.observableArrayList();
		ObservableList<Module> selected34 = FXCollections.observableArrayList();
		ObservableList<Module> unselected34 = FXCollections.observableArrayList();

		for (Module m : sortModules(course.getAllModulesOnCourse())) {
			if (m.getRunPlan() == Block.BLOCK_1 && m.isMandatory()) b1.add(m);
			else if (m.getRunPlan() == Block.BLOCK_2 && m.isMandatory()) b2.add(m);
			else if (m.getRunPlan() == Block.BLOCK_3_4) {
				if (m.isMandatory()) selected34.add(m);
				else unselected34.add(m);
			}
		}

		smp.getSelectedBlock1ListView().setItems(b1);
		smp.getSelectedBlock2ListView().setItems(b2);
		smp.getSelectedBlock34ListView().setItems(selected34);
		smp.getUnselectedBlock34ListView().setItems(unselected34);
		updateCreditsLabel();
	}

	private void applySelectedModulesFromModel(Set<Module> selected) {
		// Reset first, then move any optional block3/4 module from unselected to selected
		populateSelectModulesForCourse(activeCourse);
		List<Module> optional = selected.stream()
				.filter(m -> m.getRunPlan() == Block.BLOCK_3_4 && !m.isMandatory())
				.toList();
			for (Module opt : optional) {
				// match by code in listviews (instances may differ)
				Module inUnselected = findByCode(smp.getUnselectedBlock34ListView().getItems(), opt.getModuleCode());
				if (inUnselected != null) {
					moveModule(inUnselected, smp.getUnselectedBlock34ListView(), smp.getSelectedBlock34ListView());
				}
			}
	}

	private void populateReserveModulesEmpty() {
		rmp.getUnselectedListView().getItems().clear();
		rmp.getReservedListView().getItems().clear();
	}

	private void populateOverviewEmpty() {
		op.setProfileText("");
		op.setSelectedText("");
		op.setReservedText("");
	}

	private void populateReserveModulesFromRemaining() {
		List<Module> remaining = new ArrayList<>(smp.getUnselectedBlock34ListView().getItems());
		rmp.getUnselectedListView().setItems(FXCollections.observableArrayList(sortModules(remaining)));
		rmp.getReservedListView().getItems().clear();
	}

	private void populateOverviewFromModel() {
		if (model.getStudentCourse() == null) {
			populateOverviewEmpty();
			return;
		}

		String profile = "P Number: " + nullToEmpty(model.getStudentPnumber()) + "\n" +
				"Name: " + nullToEmpty(model.getStudentName() == null ? "" : model.getStudentName().getFullName()) + "\n" +
				"Email: " + nullToEmpty(model.getStudentEmail()) + "\n" +
				"Submission Date: " + (model.getSubmissionDate() == null ? "" : model.getSubmissionDate()) + "\n" +
				"Course: " + (model.getStudentCourse() == null ? "" : model.getStudentCourse().getCourseName());

		String selected = formatModules(model.getAllSelectedModules());
		String reserved = formatModules(model.getAllReservedModules());

		op.setProfileText(profile);
		op.setSelectedText(selected);
		op.setReservedText(reserved);
	}

	private String formatModules(Set<Module> modules) {
		if (modules == null || modules.isEmpty()) return "";
		return modules.stream()
				.sorted(Comparator.naturalOrder())
				.map(m -> m.getModuleCode() + " - " + m.getModuleName() + " (" + m.getModuleCredits() + " credits, " + (m.isMandatory() ? "Compulsory" : "Optional") + ")")
				.collect(Collectors.joining("\n"));
	}

	private void updateCreditsLabel() {
		smp.setCredits(getCurrentSelectedCredits());
	}

	private int getCurrentSelectedCredits() {
		int total = 0;
		for (Module m : smp.getSelectedBlock1ListView().getItems()) total += m.getModuleCredits();
		for (Module m : smp.getSelectedBlock2ListView().getItems()) total += m.getModuleCredits();
		for (Module m : smp.getSelectedBlock34ListView().getItems()) total += m.getModuleCredits();
		return total;
	}

	private int countOptionalChosen() {
		return (int) smp.getSelectedBlock34ListView().getItems().stream().filter(m -> !m.isMandatory()).count();
	}

	private void moveModule(Module m, ListView<Module> from, ListView<Module> to) {
		from.getItems().remove(m);
		to.getItems().add(m);
		to.getItems().sort(Comparator.naturalOrder());
		from.getItems().sort(Comparator.naturalOrder());
	}

	private List<Module> sortModules(Collection<Module> modules) {
		return modules.stream().sorted(Comparator.naturalOrder()).toList();
	}

	private Module findByCode(List<Module> modules, String code) {
		for (Module m : modules) {
			if (m.getModuleCode().equals(code)) return m;
		}
		return null;
	}

	private Course matchCourseFromLoaded(Course loadedCourse) {
		if (loadedCourse == null) return null;
		for (Course c : courses) {
			if (c.getCourseName().equals(loadedCourse.getCourseName())) return c;
		}
		return null;
	}

	private List<String> validateProfile(Course course, String pnum, Name name, String email, LocalDate date) {
		List<String> errors = new ArrayList<>();
		if (course == null) errors.add("Please select a course.");
		if (pnum.isEmpty()) errors.add("P number is required.");
		else if (!pnum.matches("(?i)^P\\d{7}$")) errors.add("P number should look like P1234567.");
		String first = name == null ? "" : safeTrim(name.getFirstName());
		String last = name == null ? "" : safeTrim(name.getFamilyName());
		if (first.isEmpty()) errors.add("First name is required.");
		if (last.isEmpty()) errors.add("Surname is required.");
		if (email.isEmpty()) errors.add("Email is required.");
		else if (!email.matches("^.+@.+\\..+$")) errors.add("Email does not look valid.");
		if (date == null) errors.add("Submission date is required.");
		return errors;
	}

	private void showError(String title, String message) {
		Alert a = new Alert(AlertType.ERROR);
		a.setTitle(title);
		a.setHeaderText(title);
		a.setContentText(message);
		a.showAndWait();
	}

	private void showInfo(String title, String message) {
		Alert a = new Alert(AlertType.INFORMATION);
		a.setTitle(title);
		a.setHeaderText(null);
		a.setContentText(message);
		a.showAndWait();
	}

	private String safeTrim(String s) { return s == null ? "" : s.trim(); }
	private String nullToEmpty(String s) { return s == null ? "" : s; }

	// -------------------- Data generation --------------------

	private Course[] generateAndGetCourses() {
		Module ctec3701 = new Module("CTEC3701", "Software Development: Methods & Standards", 30, true, Block.BLOCK_1);

		Module ctec3702 = new Module("CTEC3702", "Big Data and Machine Learning", 30, true, Block.BLOCK_2);
		Module ctec3703 = new Module("CTEC3703", "Mobile App Development and Big Data", 30, true, Block.BLOCK_2);

		Module ctec3451 = new Module("CTEC3451", "Development Project", 30, true, Block.BLOCK_3_4);

		Module ctec3704 = new Module("CTEC3704", "Functional Programming", 30, false, Block.BLOCK_3_4);
		Module ctec3705 = new Module("CTEC3705", "Advanced Web Development", 30, false, Block.BLOCK_3_4);

		Module imat3711 = new Module("IMAT3711", "Privacy and Data Protection", 30, false, Block.BLOCK_3_4);
		Module imat3722 = new Module("IMAT3722", "Fuzzy Logic and Inference Systems", 30, false, Block.BLOCK_3_4);

		Module ctec3706 = new Module("CTEC3706", "Embedded Systems and IoT", 30, false, Block.BLOCK_3_4);

		Course compSci = new Course("Computer Science");
		compSci.addModule(ctec3701);
		compSci.addModule(ctec3702);
		compSci.addModule(ctec3451);
		compSci.addModule(ctec3704);
		compSci.addModule(ctec3705);
		compSci.addModule(imat3711);
		compSci.addModule(imat3722);

		Course softEng = new Course("Software Engineering");
		softEng.addModule(ctec3701);
		softEng.addModule(ctec3703);
		softEng.addModule(ctec3451);
		softEng.addModule(ctec3704);
		softEng.addModule(ctec3705);
		softEng.addModule(ctec3706);

		Course[] cs = new Course[2];
		cs[0] = compSci;
		cs[1] = softEng;
		return cs;
	}
}
