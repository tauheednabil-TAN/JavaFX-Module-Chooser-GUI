package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import model.Module;

/** Reserve Modules tab. Allows selecting exactly one reserve module from remaining options. */
public class ReserveModulesPane extends HBox {

	private final ListView<Module> lvUnselected;
	private final ListView<Module> lvReserved;
	private final Button btnAdd;
	private final Button btnRemove;
	private final Button btnConfirm;

	public ReserveModulesPane() {
		this.setSpacing(10);
		this.setPadding(new Insets(10));

		lvUnselected = new ListView<>();
		lvReserved = new ListView<>();
		lvUnselected.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		lvReserved.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

		btnAdd = new Button("Add ▶");
		btnRemove = new Button("◀ Remove");
		btnConfirm = new Button("Confirm");

		VBox vbButtons = new VBox(10, btnAdd, btnRemove, new Label(), btnConfirm);
		vbButtons.setAlignment(Pos.CENTER);

		VBox left = new VBox(5, new Label("Available modules"), lvUnselected);
		VBox right = new VBox(5, new Label("Reserve module"), lvReserved);
		HBox.setHgrow(left, Priority.ALWAYS);
		HBox.setHgrow(right, Priority.ALWAYS);
		VBox.setVgrow(lvUnselected, Priority.ALWAYS);
		VBox.setVgrow(lvReserved, Priority.ALWAYS);

		this.getChildren().addAll(left, vbButtons, right);
	}

	public ListView<Module> getUnselectedListView() { return lvUnselected; }
	public ListView<Module> getReservedListView() { return lvReserved; }

	public void addAddHandler(EventHandler<ActionEvent> handler) { btnAdd.setOnAction(handler); }
	public void addRemoveHandler(EventHandler<ActionEvent> handler) { btnRemove.setOnAction(handler); }
	public void addConfirmHandler(EventHandler<ActionEvent> handler) { btnConfirm.setOnAction(handler); }

	public void setControlsEnabled(boolean enabled) {
		btnAdd.setDisable(!enabled);
		btnRemove.setDisable(!enabled);
		btnConfirm.setDisable(!enabled);
	}
}
