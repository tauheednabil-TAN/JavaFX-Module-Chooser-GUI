package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import model.Module;

/**
 * Select Modules tab.
 * 
 * Shows compulsory block 1 & 2 modules, and allows choosing an optional block 3/4 module.
 */
public class SelectModulesPane extends BorderPane {

	private final ListView<Module> lvSelectedBlock1;
	private final ListView<Module> lvSelectedBlock2;
	private final ListView<Module> lvUnselectedBlock34;
	private final ListView<Module> lvSelectedBlock34;

	private final Button btnAdd;
	private final Button btnRemove;
	private final Button btnReset;
	private final Button btnSubmit;
	private final Label lblCredits;

	public SelectModulesPane() {
		this.setPadding(new Insets(10));

		lvSelectedBlock1 = new ListView<>();
		lvSelectedBlock2 = new ListView<>();
		lvUnselectedBlock34 = new ListView<>();
		lvSelectedBlock34 = new ListView<>();

		lvSelectedBlock1.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		lvSelectedBlock2.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		lvUnselectedBlock34.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		lvSelectedBlock34.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

		// Top: compulsory modules
		GridPane gpTop = new GridPane();
		gpTop.setHgap(15);
		gpTop.setVgap(5);
		gpTop.setPadding(new Insets(5));

		gpTop.add(new Label("Selected Block 1"), 0, 0);
		gpTop.add(new Label("Selected Block 2"), 1, 0);
		gpTop.add(lvSelectedBlock1, 0, 1);
		gpTop.add(lvSelectedBlock2, 1, 1);
		GridPane.setHgrow(lvSelectedBlock1, Priority.ALWAYS);
		GridPane.setHgrow(lvSelectedBlock2, Priority.ALWAYS);
		lvSelectedBlock1.setPrefHeight(110);
		lvSelectedBlock2.setPrefHeight(110);

		// Centre: block 3/4 selection
		Label lblUnselected = new Label("Unselected Block 3/4");
		Label lblSelected = new Label("Selected Block 3/4");

		btnAdd = new Button("Add ▶");
		btnRemove = new Button("◀ Remove");
		VBox vbButtons = new VBox(10, btnAdd, btnRemove);
		vbButtons.setAlignment(Pos.CENTER);

		HBox hbMid = new HBox(10,
				new VBox(5, lblUnselected, lvUnselectedBlock34),
				vbButtons,
				new VBox(5, lblSelected, lvSelectedBlock34));
		hbMid.setPadding(new Insets(10, 5, 10, 5));
		hbMid.setAlignment(Pos.CENTER);
		HBox.setHgrow(lvUnselectedBlock34, Priority.ALWAYS);
		HBox.setHgrow(lvSelectedBlock34, Priority.ALWAYS);
		VBox.setVgrow(lvUnselectedBlock34, Priority.ALWAYS);
		VBox.setVgrow(lvSelectedBlock34, Priority.ALWAYS);

		// Bottom: credits + reset/submit
		lblCredits = new Label("Credits: 0");
		btnReset = new Button("Reset");
		btnSubmit = new Button("Submit");
		HBox hbBottom = new HBox(10, lblCredits, new HBox(), btnReset, btnSubmit);
		HBox.setHgrow(hbBottom.getChildren().get(1), Priority.ALWAYS);
		hbBottom.setAlignment(Pos.CENTER_LEFT);
		hbBottom.setPadding(new Insets(5));

		this.setTop(gpTop);
		this.setCenter(hbMid);
		this.setBottom(hbBottom);
	}

	public ListView<Module> getSelectedBlock1ListView() { return lvSelectedBlock1; }
	public ListView<Module> getSelectedBlock2ListView() { return lvSelectedBlock2; }
	public ListView<Module> getUnselectedBlock34ListView() { return lvUnselectedBlock34; }
	public ListView<Module> getSelectedBlock34ListView() { return lvSelectedBlock34; }

	public void setCredits(int credits) { lblCredits.setText("Credits: " + credits); }

	public void addAddHandler(EventHandler<ActionEvent> handler) { btnAdd.setOnAction(handler); }
	public void addRemoveHandler(EventHandler<ActionEvent> handler) { btnRemove.setOnAction(handler); }
	public void addResetHandler(EventHandler<ActionEvent> handler) { btnReset.setOnAction(handler); }
	public void addSubmitHandler(EventHandler<ActionEvent> handler) { btnSubmit.setOnAction(handler); }

	public void setSelectionControlsEnabled(boolean enabled) {
		btnAdd.setDisable(!enabled);
		btnRemove.setDisable(!enabled);
		btnReset.setDisable(!enabled);
		btnSubmit.setDisable(!enabled);
	}
}
