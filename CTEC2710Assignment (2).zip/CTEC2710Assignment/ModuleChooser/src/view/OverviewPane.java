package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;

/** Overview Selection tab. Displays user details, selected modules and reserve module. */
public class OverviewPane extends BorderPane {

	private final TextArea taProfile;
	private final TextArea taSelected;
	private final TextArea taReserved;
	private final Button btnSave;

	public OverviewPane() {
		this.setPadding(new Insets(10));

		taProfile = new TextArea();
		taSelected = new TextArea();
		taReserved = new TextArea();
		taProfile.setEditable(false);
		taSelected.setEditable(false);
		taReserved.setEditable(false);
		taProfile.setWrapText(true);
		taSelected.setWrapText(true);
		taReserved.setWrapText(true);

		GridPane gp = new GridPane();
		gp.setHgap(10);
		gp.setVgap(6);

		gp.add(new Label("Student Details"), 0, 0);
		gp.add(new Label("Selected Modules"), 0, 2);
		gp.add(new Label("Reserve Module"), 1, 2);

		gp.add(taProfile, 0, 1, 2, 1);
		gp.add(taSelected, 0, 3);
		gp.add(taReserved, 1, 3);

		GridPane.setHgrow(taProfile, Priority.ALWAYS);
		GridPane.setVgrow(taProfile, Priority.ALWAYS);
		GridPane.setHgrow(taSelected, Priority.ALWAYS);
		GridPane.setVgrow(taSelected, Priority.ALWAYS);
		GridPane.setHgrow(taReserved, Priority.ALWAYS);
		GridPane.setVgrow(taReserved, Priority.ALWAYS);

		btnSave = new Button("Save Overview");
		BorderPane.setMargin(btnSave, new Insets(10, 0, 0, 0));
		this.setCenter(gp);
		this.setBottom(btnSave);
	}

	public void setProfileText(String text) { taProfile.setText(text == null ? "" : text); }
	public void setSelectedText(String text) { taSelected.setText(text == null ? "" : text); }
	public void setReservedText(String text) { taReserved.setText(text == null ? "" : text); }

	public String getProfileText() { return taProfile.getText(); }
	public String getSelectedText() { return taSelected.getText(); }
	public String getReservedText() { return taReserved.getText(); }

	public void addSaveOverviewHandler(EventHandler<ActionEvent> handler) { btnSave.setOnAction(handler); }
	public void setControlsEnabled(boolean enabled) { btnSave.setDisable(!enabled); }
}
